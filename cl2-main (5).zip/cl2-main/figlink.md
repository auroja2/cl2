https://www.figma.com/design/hYXky9wZm2Fy1InolKPDcx/All-UI-UX?node-id=0-1&t=82trZeqEf0EQGQuP-1


extension - https://www.figma.com/community/plugin/1355208994639626356/codia-ai-designgen-prompt-to-design-magic
Wireframe Designer
